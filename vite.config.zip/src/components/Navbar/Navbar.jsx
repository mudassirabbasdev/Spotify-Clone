import { navLinks } from "../../data/nav";
import { circleIcon } from "../../lib/classes";

const btn = "bg-transparent text-[13.333px] font-normal text-white opacity-50 hover:opacity-100";

export default function Navbar({ query, onQuery }) {
  return (
    <div className="fixed top-0 z-[1000] flex w-[98%] items-center justify-between bg-black p-1">
      <div className="flex w-[120px] items-center gap-5">
        <img src="./images/brand/icon.png" className="w-10" alt="Spotify" />
        <i className={`fa-solid fa-house ${circleIcon}`}></i>
      </div>
      <div className="flex-1 pl-2.5">
        <input
          type="text"
          placeholder="What do you want to play?"
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          className="box-content block h-6 w-[70%] rounded-[20px] border-none bg-white px-5 py-2.5 text-[13.333px] text-black outline-none"
        />
      </div>
      <div className="flex items-center gap-[15px] font-bold">
        {navLinks.map((l) => (
          <a href="#" key={l} className="text-white no-underline opacity-50 hover:opacity-100">
            {l}
          </a>
        ))}
        <button className={`${btn} rounded-[20px] px-2.5 py-[5px]`}>
          <i className={`fa-solid fa-circle-arrow-down ${circleIcon}`}></i> Install App
        </button>
        <button className={btn}>Sign up</button>
        <button className="rounded-[20px] bg-white px-[15px] py-1.5 text-[13.333px] font-normal text-black">
          Log in
        </button>
      </div>
    </div>
  );
}

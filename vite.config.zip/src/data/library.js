export const libraryBoxes = [
  { title: "Create your first playlist", text: "It's easy, we'll help you", cta: "Create playlist" },
  { title: "Let's find some podcast to follow", text: "We'll keep you updated on new episodes", cta: "Browse podcasts" },
];

export const legalLinks = [
  "Legal",
  "Safety & Privacy Center",
  "Privacy Policy",
  "Cookies",
  "About Ads",
  "Accessibility",
];

import { useMemo, useState } from "react";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import Section from "./components/Section";
import Footer from "./components/Footer";
import { sections } from "./data/sections";

export default function App() {
  const [query, setQuery] = useState("");

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return sections;
    return sections
      .map((s) => ({
        ...s,
        cards: s.cards.filter((c) =>
          `${c.title || ""} ${c.info}`.toLowerCase().includes(q)
        ),
      }))
      .filter((s) => s.cards.length);
  }, [query]);

  return (
    <div className="flex h-screen flex-col">
      <Navbar query={query} onQuery={setQuery} />
      <div className="mt-[85px] flex h-screen w-full">
        <Sidebar />
        <div className="flex-1 overflow-auto rounded-2xl bg-[#121212] px-6 text-white">
          <div>
            {visible.map((s) => (
              <Section key={s.title} {...s} />
            ))}
            {!visible.length && <h2 className="my-[0.83em] text-[1.5rem] font-bold">No results for "{query}"</h2>}
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
}
